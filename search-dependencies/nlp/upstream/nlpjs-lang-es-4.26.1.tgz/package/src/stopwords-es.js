/*
 * Copyright (c) AXA Group Operations Spain S.A.
 *
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

const { Stopwords } = require('@nlpjs/core');

class StopwordsEs extends Stopwords {
  constructor(container, words) {
    super(container);
    this.name = 'stopwords-es';
    this.dictionary = {};
    const list = words || [
      'a',
      'un',
      'el',
      'ella',
      'y',
      'sobre',
      'de',
      'la',
      'que',
      'en',
      'los',
      'del',
      'se',
      'las',
      'por',
      'un',
      'para',
      'con',
      'no',
      'una',
      'su',
      'al',
      'lo',
      'como',
      'más',
      'pero',
      'sus',
      'le',
      'ya',
      'o',
      'porque',
      'cuando',
      'muy',
      'sin',
      'sobre',
      'también',
      'me',
      'hasta',
      'donde',
      'quien',
      'desde',
      'nos',
      'durante',
      'uno',
      'ni',
      'contra',
      'ese',
      'eso',
      'mí',
      'qué',
      'otro',
      'él',
      'cual',
      'poco',
      'mi',
      'tú',
      'te',
      'ti',
      'sí',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      '0',
      '_',
    ];
    this.build(list);
  }
}

module.exports = StopwordsEs;
